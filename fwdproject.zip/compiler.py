import os, filecmp
import time
codes = {200:'success',404:'file not found',400:'Opps! Someting went wrong Please Check your code again ',408:'timeout'}

def compile(file,lang):
    if lang == 'java':
        class_file = file[:-4]+"class"
    elif lang == 'c':
        class_file = file[:-2]
    elif lang=='cpp':
        class_file = file[:-4]

    if (os.path.isfile(class_file)):
        os.remove(class_file)
    if (os.path.isfile(file)):
        if lang == 'java':
            os.system('javac '+file)
        elif lang == 'c' or lang == 'cpp':
            os.system('gcc -o '+class_file+' '+file)
        if (os.path.isfile(class_file)):
            return 200
        else:
            return 400
    else:
        return 404

def run(file,input,timeout,lang):
    if lang == 'java':
        cmd = 'java '+file
    elif lang=='c' or lang=='cpp':
        cmd = './'+file
    r = os.system('timeout '+timeout+' '+cmd+' < '+input+' > out.txt')
    if lang == 'java':
        os.remove(file+'.class')
    elif lang == 'c' or lang == 'cpp':
        os.remove(file)
    if r==0:
        return 200
    elif r==31744:
        os.remove('out.txt')
        return 408
    else:
        os.remove('out.txt')
        return 400

def match(output):
    if os.path.isfile('out.txt') and os.path.isfile(output):
        b = filecmp.cmp('out.txt',output)
        #os.remove('out.txt')
	if(b == False):
		b = "Wrong";
	else:
		b="Correct";
        return b
    else:
        return 404

while(1):

	for file in os.listdir("/opt/lampp/htdocs/compi"):
		print(file)
		
		ary = os.path.splitext(file)
		if(ary[1] == '.c'):
			testin = '/opt/lampp/htdocs/testin.txt'
			testout = '/opt/lampp/htdocs/testout.txt'
			timeout = '1' # secs
			lang = 'c'
			with open('/opt/lampp/htdocs/'+ary[0]+'.txt' , 'w') as f:
				if(codes[compile(file,lang)] != "success"):
					x=codes[compile(file,lang)]
					f.write("Opps! Someting went wrong Please Check your code again")
					
			
				elif(codes[run(ary[0],testin,timeout,lang)] != "success"):
					codes[compile(file,lang)]
					f.write(codes[run(ary[0],testin,timeout,lang)])
									
				else:	
					codes[compile(file,lang)]
					codes[run(ary[0],testin,timeout,lang)]
					f.write(match(testout))
					
				
				os.remove(file)
			

		elif(ary[1] == '.cpp'):
			lang= 'cpp'
			testin = '/opt/lampp/htdocs/testin.txt'
			testout = '/opt/lampp/htdocs/testout.txt'
			timeout = '1' # secs
			with open('/opt/lampp/htdocs/'+ary[0]+'.txt' , 'w') as f:
				f.write(codes[compile(file,lang)])
				f.write('\n')
				f.write(codes[run(ary[0],testin,timeout,lang)])
				f.write('\n')
				f.write(match(testout))
				os.remove('out.txt')
				os.remove(file)


		elif(ary[1] == '.java'):
			testin = '/opt/lampp/htdocs/testin.txt'
			testout = '/opt/lampp/htdocs/testout.txt'
			timeout = '1' # secs			
			lang= 'java'
			with open('/opt/lampp/htdocs/'+ary[0]+'.txt' , 'w') as f:
				f.write(codes[compile(file,lang)])
				f.write('\n')
				f.write(codes[run(ary[0],testin,timeout,lang)])
				f.write('\n')
				f.write(match(testout))
				os.remove('out.txt')
				os.remove(file)
		else:
			lang='l'

	
		


