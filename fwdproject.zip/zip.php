<?php

session_start();
//$email = $_SESSION["email"];
$email = "rohit.mehta@technonjr.org";
$conn = mysql_connect("localhost","root","");
mysql_select_db("compiler");

					
					
					
					$sql="SELECT * FROM login WHERE email='$email'";
					$result  = mysql_query($sql); 
					$row = mysql_fetch_array($result);
					$random1 = $row['id'];
					$_SESSION["id"] = $random1;
					
				
					
					$target_file = "compi/".basename($_FILES["pic"]["name"]);
					$filename = $random1;
					$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			
						move_uploaded_file($_FILES["pic"]['tmp_name'],"compi/".$filename.".".$imageFileType);
				
						fopen($filename.".txt", "w");


						$file = $filename.".".$imageFileType;
						$file1 = $filename.".txt";
						$sql="INSERT INTO content (name	 , output) VALUES("."'$file'".","."'$file1'".")";
						$result  = mysql_query($sql);
						
						
				
					header("Location:p.php");
				?>
		
