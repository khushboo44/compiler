

		<html>
			<head>
				
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">





<link rel="stylesheet" href="font-awesome.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>				
<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js" ></script>
<script src="bootstrap/js/bootstrap.min.js" ></script>				
				
				

				<title>Notes</title>
			</head>
			<body style="background-color:black">
				<div>
					<iframe src="https://ideone.com" style="border:1px solid #c0c0c0; overflow-x hidden; " frameborder="0" height="600px" width="100%"></iframe>
				</div>
	
				<div>			
				
					
					<h6 style="color:black">.</h6>
					<div align="center">
						<a href="#myModal" role="button" class="btn btn-default" data-toggle="modal" ><h4>Your Code&nbsp;<span class=" glyphicon glyphicon-plus"></span></h4></a>
					</div>		
						<div class="modal fade" id="myModal">
							<div class="modal-dialog">
								<div class="modal-content">
									
											
									<div class="modal-body">										
										<form class="form-horizontal" action="zip.php" method="POST" enctype="multipart/form-data">
										
																							
											<div class="form-group" align="center">
												<label id="preab" class="btn btn-success btn-file  ">
												<h5 id="fileadded" >&nbsp;Add notes</h5><input id="prefil" onchange="validate_file(this.value)" type="file" name="pic" value="" style="display: none;" required>
												</label>											
											</div>
																							
											<div class="form-group col-lg-3" align="center">
												<label id="sub" class="btn btn-warning hide ">
													upload<input name="submit"  class="form-control" value="submit" type="submit" style="display: none;">
												<label>
											</div>											
										</form>											
									</div><!-- end modal-body -->										
								</div><!-- end model-content -->
							</div> <!-- end model-dialog -->
						</div><!-- end myModal -->

		<br/>
				
			
		<script>
			
		
			
				
			
			
			function validate_file(filename)
			{	
						
				var x =filename.substr(filename.lastIndexOf('.')+1);
				//var z =filename.files[0].size;	
				
				var fs = document.getElementById('prefil').files[0].size;
					fs = fs/1024;
					fs = fs/1024;
					if(((x == 'c') || (x == 'cpp') || (x == 'java')&& (fs<20)))
					{
							$("#fileadded").html("File added");
				$("#sub").removeClass("btn btn-warning hide").addClass("btn btn-warning");
				
					}
					
					else
					{
						if(fs>20)
						{
							$("#fileadded").html("File must be less than 20Mb");
							$("#sub").removeClass("btn btn-warning").addClass("btn btn-warning hide");
							
						}
						else
						{
							$("#fileadded").html("Only for C, Cpp, Java Programs");
							$("#sub").removeClass("btn btn-warning").addClass("btn btn-warning hide");
						}
					}
				
				
			}
			
			
		</script>
	
	</body>
</html>
