<?php

$nam = $_POST["name"];
$email = $_POST["ema"];

$_SESSION["name"]=$nam;
$_SESSION["email"]=$email;


?>
		
