<?php
session_start();
$conn = mysql_connect("localhost","root","");
mysql_select_db("compiler");

$email = "rohit.mehta@technonjr.org";
$name = "Rohit Mehta";
/*

$email = $_SESSION["email"];
$name = $_SESSION["name"];
*/

$sql = "SELECT * FROM login WHERE email = '$email'";
$result  = mysql_query($sql);

$count = mysql_num_rows($result);

if($count == 0)
{
	$sql="INSERT INTO login (email , name) VALUES('$email' , '$name')";
	mysql_query($sql, $conn);
	header("Location:pythonproj.php");
}

?>
		
