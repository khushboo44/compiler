<?php
	error_reporting(E_ERROR);
?>

		<html>
			<head>
				
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">





<link rel="stylesheet" href="font-awesome.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>				
<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js" ></script>
<script src="bootstrap/js/bootstrap.min.js" ></script>				
				
				

				<title>Notes</title>
			</head>
			<body style="background-color:black">
				
    

	
				<div>			
				
					
					<h6 style="color:black">.</h6>
					<div align="center">
					<?php
						$myfile = fopen("1.txt", "r") ;
											
					?>
		
					  <h1 style="color:white"><?php echo fread($myfile,filesize("1.txt")); ?></h1>						
					  <h6 style="color:white"><?php echo filesize("1.txt")*.0009765625;?>&nbsp;KB</h6>
						
	<?php
	file_put_contents("1.txt","");
	fclose($myfile);
?>	
					
	
	</body>
</html>


