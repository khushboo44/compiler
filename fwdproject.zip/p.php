 <?php

//error_reporting(E_ERROR);

$myfile = fopen("1.txt", "r") ;

if(filesize("1.txt") == 0)
{
	echo "Loading...";	

	
	$c = 5;
	

	header("Refresh:$c ;url=p.php");

}
else
{

header("Location:success.php");
}
fclose($myfile);
?> 
